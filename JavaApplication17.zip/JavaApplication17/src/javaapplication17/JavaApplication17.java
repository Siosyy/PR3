/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication17;

/**
 *
 * @author Student
 */
public class JavaApplication17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          int num1 = 6;
        int num2 = 40;
        if(num1 > num2){
            System.out.println("число num1 больше числа num2");
        }
        else if(num1 < num2){
            System.out.println("число num1 меньше числа num2");
        }

    }
    
}
