/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package razdel1;

import java.util.Random;

/**
 *
 * @author Student
 */
public class zadanie54 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         int[] wins = new int[20];
        Random random = new Random();
        
        // Заполняем массив случайными числами от 0 до 5
        System.out.println("Количество побед по командам:");
        for (int i = 0; i < wins.length; i++) {
            wins[i] = random.nextInt(6); // числа от 0 до 5
            System.out.println("Команда " + (i + 1) + ": " + wins[i] + " побед");
        }
        
        // Поиск команд с более чем 3 победами
        System.out.println("\nКоманды с более чем 3 победами:");
        boolean found = false;
        
        for (int i = 0; i < wins.length; i++) {
            if (wins[i] > 3) {
                System.out.println("Команда №" + (i + 1) + " - " + wins[i] + " побед");
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("Нет команд с более чем 3 победами");
        }
        
        // Дополнительная статистика
        printStatistics(wins);
    }
    
    // Метод для вывода дополнительной статистики
    public static void printStatistics(int[] wins) {
        int countMoreThan3 = 0;
        int maxWins = 0;
        int bestTeam = -1;
        
        for (int i = 0; i < wins.length; i++) {
            if (wins[i] > 3) {
                countMoreThan3++;
            }
            if (wins[i] > maxWins) {
                maxWins = wins[i];
                bestTeam = i + 1;
            }
        }
        
        System.out.println("\nСтатистика:");
        System.out.println("Всего команд с более чем 3 победами: " + countMoreThan3);
        System.out.println("Максимальное количество побед: " + maxWins + " (Команда №" + bestTeam + ")");
    }
    
}
