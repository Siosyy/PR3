/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package razdel1;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class zadanie4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int[] array = new int [20];  
        for (int i4 = 0; i4 < array.length; i4++) {  
         array[i4] = (int) (Math.random() * 100); // Заполняем случайными числами от 0 до 99  
        }  
          
        Scanner scanner = new Scanner(System.in);        
          
        // Ввод границ поиска  
        System.out.print("Введите n (от 1 до 20): ");  
 int n = scanner.nextInt();
        System.out.print("Введите k (от 1 до 20, k >= n): ");  
int k = scanner.nextInt(); 
        
        
          
        // Проверка корректности ввода  
        if (n < 1 || n > 20 || k < 1 || k > 20 || n > k) {  
            System.out.println("Ошибка: неверные значения n и/или k");  
            return;  
        }  
          
        // Поиск минимального элемента  
        int min = array[n - 1]; // Начинаем с первого элемента диапазона  
        for (int i4 = n - 1; i4 <= k - 1; i4++) {  
            if (array[i4] < min) {  
                min = array[i4];  
            }  
        }  
          
        System.out.println("Минимальный элемент в диапазоне [" + n + "," + k + "]: " + min);  
    }  
}

    
    

