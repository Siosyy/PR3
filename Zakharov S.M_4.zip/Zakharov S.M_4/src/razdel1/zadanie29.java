/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package razdel1;

/**
 *
 * @author Student
 */
public class zadanie29 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
          int[] A = new int[20];
        for (int i = 0; i < A.length; i++) {
            A[i] = (int)(Math.random() * 100); 
        }
    
        System.out.println("Исходный массив:");
        for (int i = 0; i < A.length; i++) {
            System.out.print(A[i] + " ");
        }
        System.out.println();
        
        
        int minValue = Integer.MAX_VALUE; 
        int minIndex = -1; 
        
       
        for (int i = 1; i < A.length; i += 2) {
            if (A[i] < minValue) {
                minValue = A[i];
                minIndex = i;
            }
        }
        
        
        if (minIndex != -1) {
           
            int position = minIndex + 1;
            System.out.println("Минимальный элемент на четных позициях: " + minValue);
            System.out.println("Его позиция в массиве: " + position);
            System.out.println("Индекс в массиве: " + minIndex);
        } else {
            System.out.println("В массиве нет элементов на четных позициях");
        }   
    }
}
